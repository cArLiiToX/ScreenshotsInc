
self.addEventListener('message', function(e) {
  var data = e.data;
  switch (data.method) {
    case 'distort_path':
      break;
  };
}, false);
