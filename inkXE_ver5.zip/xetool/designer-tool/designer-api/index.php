<?php
define('accessUser', 'inkXE');

/* Load core files */
require_once 'bootstrap.php';

Flight::start();
