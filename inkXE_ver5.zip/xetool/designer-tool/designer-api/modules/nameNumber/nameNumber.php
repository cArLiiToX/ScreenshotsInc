<?php
/* Check Un-authorize Access */
if (!defined('accessUser')) {
    die("Error");
}

class NameNumber extends UTIL
{
}
