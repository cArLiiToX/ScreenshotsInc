<?php
/* Check Un-authorize Access */
if (!defined('accessUser')) {
    die("Error");
}

class TextArt extends UTIL
{

}
