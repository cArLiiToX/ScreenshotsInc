<?php
/* Check Un-authorize Access */
if (!defined('accessUser')) {
    die("Error");
}

class TextWithinShape extends UTIL
{

}
